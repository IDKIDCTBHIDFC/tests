#include <stdio.h>
#include <graphics.h>
#include <math.h>
#include <conio.h>

// Screen Center (Origin for visualization)
int midX, midY;

// Structure for a Point
typedef struct {
    double x;
    double y;
    double w;
} Point;

// Custom Line Drawing Function using putpixel (DDA Algorithm)
void drawLine(int x1, int y1, int x2, int y2, int color) {
    // 1. Calculate steps
    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps = (abs(dx) > abs(dy)) ? abs(dx) : abs(dy);
    
    // 2. Calculate increment
    float xInc = dx / (float)steps;
    float yInc = dy / (float)steps;
    
    float x = x1;
    float y = y1;
    
    // 3. Plot points
    for(int i = 0; i <= steps; i++) {
        // We add midX and midY to shift (0,0) to the center of the screen
        // We subtract y from midY because computer screens have Y increasing downwards
        putpixel(midX + (int)(x + 0.5), midY - (int)(y + 0.5), color);
        x += xInc;
        y += yInc;
    }
}

// Function to draw a Triangle connecting 3 points
void drawTriangle(Point p[], int color) {
    drawLine(p[0].x, p[0].y, p[1].x, p[1].y, color);
    drawLine(p[1].x, p[1].y, p[2].x, p[2].y, color);
    drawLine(p[2].x, p[2].y, p[0].x, p[0].y, color);
}

void rotateTriangle(Point p[]) {
    int i;
    double newX, newY;
    
    // Homogeneous Matrix for +90 Degree Rotation
    // | cos90  -sin90   0 |   |  0  -1   0 |
    // | sin90   cos90   0 | = |  1   0   0 |
    // |   0       0     1 |   |  0   0   1 |
    
    double matrix[3][3] = {
        {0, -1, 0},
        {1,  0, 0},
        {0,  0, 1}
    };
    
    for(i = 0; i < 3; i++) {
        // Matrix Multiplication
        // x' = (0 * x) + (-1 * y) + (0 * 1)
        // y' = (1 * x) + (0 * y)  + (0 * 1)
        newX = (matrix[0][0] * p[i].x) + (matrix[0][1] * p[i].y) + (matrix[0][2] * p[i].w);
        newY = (matrix[1][0] * p[i].x) + (matrix[1][1] * p[i].y) + (matrix[1][2] * p[i].w);
        
        p[i].x = newX;
        p[i].y = newY;
    }
}

int main() {
    int gd = DETECT, gm;
    
    // Triangle Coordinates (Defined in First Quadrant)
    Point tri[3] = {
        {50, 0, 1},   // Vertex A
        {100, 0, 1},  // Vertex B
        {75, 50, 1}   // Vertex C
    };
    
    initgraph(&gd, &gm, NULL);
    
    // Calculate center of screen to act as Origin (0,0)
    midX = getmaxx() / 2;
    midY = getmaxy() / 2;
    
    // Draw Axis for reference (Gray color)
    line(midX, 0, midX, getmaxy()); // Y-Axis
    line(0, midY, getmaxx(), midY); // X-Axis
    outtextxy(midX + 5, midY + 5, "(0,0)");
    
    // 1. Draw Original Triangle (RED)
    drawTriangle(tri, RED);
    outtextxy(midX + 50, midY - 60, "Original (Red)");
    
    getch(); // Wait for user key
    
    // 2. Apply Rotation
    rotateTriangle(tri);
    
    // 3. Draw Rotated Triangle (GREEN)
    // It should move from 1st Quadrant to 2nd Quadrant
    drawTriangle(tri, GREEN);
    outtextxy(midX - 120, midY - 60, "Rotated +90 (Green)");
    
    getch();
    closegraph();
    return 0;
}
