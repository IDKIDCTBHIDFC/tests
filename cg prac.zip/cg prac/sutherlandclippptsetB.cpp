#include <graphics.h>
#include <stdio.h>

#define LEFT   1     //0001
#define RIGHT  2     //0010
#define BOTTOM 4     //0100
#define TOP    8     //1000

int computeOutCode(int x, int y, int xmin, int ymin, int xmax, int ymax) {
    int code = 0;

    if (x < xmin)  code |= LEFT;
    else if (x > xmax) code |= RIGHT;

    if (y < ymin)  code |= BOTTOM;
    else if (y > ymax) code |= TOP;

    return code;
}

void CohenSutherlandClip(int xmin, int ymin, int xmax, int ymax,
                         int x1, int y1, int x2, int y2)
{
    int out1 = computeOutCode(x1, y1, xmin, ymin, xmax, ymax);
    int out2 = computeOutCode(x2, y2, xmin, ymin, xmax, ymax);

    int accept = 0;

    while (1) {
        if ((out1 | out2) == 0) {
            accept = 1;              // Trivial accept
            break;
        }
        else if (out1 & out2) {
            break;                   // Trivial reject
        }
        else {
            // Choose point outside the window
            int out;
            int x, y;

            out = out1 ? out1 : out2;

            if (out & TOP) {
                y = ymax;
                x = x1 + (float)(x2 - x1) * (ymax - y1) / (float)(y2 - y1);
            }
            else if (out & BOTTOM) {
                y = ymin;
                x = x1 + (float)(x2 - x1) * (ymin - y1) / (float)(y2 - y1);
            }
            else if (out & RIGHT) {
                x = xmax;
                y = y1 + (float)(y2 - y1) * (xmax - x1) / (float)(x2 - x1);
            }
            else if (out & LEFT) {
                x = xmin;
                y = y1 + (float)(y2 - y1) * (xmin - x1) / (float)(x2 - x1);
            }

            if (out == out1) {
                x1 = x;
                y1 = y;
                out1 = computeOutCode(x1, y1, xmin, ymin, xmax, ymax);
            }
            else {
                x2 = x;
                y2 = y;
                out2 = computeOutCode(x2, y2, xmin, ymin, xmax, ymax);
            }
        }
    }

    if (accept) {
        printf("Line accepted\n");
        setcolor(GREEN);
        line(x1, y1, x2, y2);
    }
    else {
        printf("Line rejected\n");
    }
}

int main() {
    int gd = DETECT, gm;
    initgraph(&gd, &gm, "");

    int xmin = 100, ymin = 100, xmax = 400, ymax = 300;

    // Draw clipping window
    setcolor(WHITE);
    rectangle(xmin, ymin, xmax, ymax);

    int x1 = 150, y1 = 150;
    int x2 = 350, y2 = 250;

    // Draw original line in RED
    setcolor(RED);
    line(x1, y1, x2, y2);

    // Clip and draw clipped line
    CohenSutherlandClip(xmin, ymin, xmax, ymax, x1, y1, x2, y2);

    getch();
    closegraph();
    return 0;
}

