#include<stdio.h>
#include<graphics.h>
#include<math.h>
#include <conio.h>

void bresenhem(int x1,int y1,int x2,int y2){
	int dx= x2-x1;
	int dy = y2-y1;
	int p0= 2*dy - dx;
	int x=x1;
	int y =y1;
	while(x<=x2){
		putpixel(x,y,WHITE);
		if(p0>=0){
			y++;
			p0=p0+2*dy-2*dx;
		}
		else{
			p0=p0+2*dy;
		}
		x++;
	}
}

int main()
{
    int gd = DETECT, gm;
    int x0, y0, x1, y1;

    printf("Enter x0 y0: ");
    scanf("%d %d", &x0, &y0);

    printf("Enter x1 y1: ");
    scanf("%d %d", &x1, &y1);

    initgraph(&gd, &gm, NULL);
    bresenhem(x0,y0,x1,y1);
    getch();
    closegraph();

    return 0;
}
