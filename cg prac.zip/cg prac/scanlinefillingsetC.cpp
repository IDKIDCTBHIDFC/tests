#include <graphics.h>
#include <stdio.h>
#include <conio.h>

typedef struct {
    int x, y;
} Point;

void scanlineFill(Point poly[], int n, int color) {
    int i, j, k, temp;
    int y; // Declare y here for Turbo C++ compatibility
    int min_y, max_y;
    int inter[50]; // Intersection array
    
    // 1. Find the Y-range of the polygon
    min_y = poly[0].y;
    max_y = poly[0].y;
    
    for(i = 1; i < n; i++) {
        if(poly[i].y < min_y) min_y = poly[i].y;
        if(poly[i].y > max_y) max_y = poly[i].y;
    }

    // 2. Scan Line Loop: From Top to Bottom
    for (y = min_y; y <= max_y; y++) {
        k = 0; // Reset intersection count for this line

        for (i = 0; i < n; i++) {
            int x1 = poly[i].x;
            int y1 = poly[i].y;
            int x2 = poly[(i + 1) % n].x;
            int y2 = poly[(i + 1) % n].y;

            // Skip horizontal edges (dy = 0)
            if (y1 == y2) continue;

            // Check if scanline 'y' cuts the edge
            // Logic: y must be between y1 and y2
            // We use < for the upper limit to handle vertex overlap issues
            if ((y >= y1 && y < y2) || (y >= y2 && y < y1)) {
                // Calculate Intersection Formula: x = x1 + slope_inverse * dy
                int x = x1 + (int)((float)(y - y1) * (x2 - x1) / (y2 - y1));
                inter[k++] = x;
            }
        }

        // 3. Sort Intersections (Bubble Sort)
        // We need x-coordinates in increasing order to fill correctly
        for (i = 0; i < k - 1; i++) {
            for (j = 0; j < k - i - 1; j++) {
                if (inter[j] > inter[j + 1]) {
                    temp = inter[j];
                    inter[j] = inter[j + 1];
                    inter[j + 1] = temp;
                }
            }
        }

        // 4. Fill Pixels between Pairs
        setcolor(color);
        for (i = 0; i < k; i += 2) {
            // Draw line from Inter[0] to Inter[1], Inter[2] to Inter[3]...
            if (i + 1 < k) {
                line(inter[i], y, inter[i + 1], y);
            }
        }
        
        // Optional: Small delay to visualize the filling process
        delay(5); 
    }
}

int main() {
    int gd = DETECT, gm;
    int n, i; // Declare i here
    Point poly[50];

    // Initialize graphics
    // Note: Use "C:\\TurboC3\\BGI" if NULL doesn't work
    initgraph(&gd, &gm, NULL); 

    printf("Enter number of vertices: ");
    scanf("%d", &n);
    
    printf("Enter vertices (x y):\n");
    for (i = 0; i < n; i++) {
        printf("Vertex %d: ", i+1);
        scanf("%d %d", &poly[i].x, &poly[i].y);
    }

    // Draw the Polygon Boundary first
    setcolor(WHITE);
    for (i = 0; i < n; i++) {
        line(poly[i].x, poly[i].y, poly[(i + 1) % n].x, poly[(i + 1) % n].y);
    }

    outtextxy(10, 10, "Press any key to start filling...");
    getch();
    
    // Call the function
    scanlineFill(poly, n, YELLOW);
    
    outtextxy(10, 30, "Filling Complete.");
    getch();
    closegraph();
    return 0;
}
