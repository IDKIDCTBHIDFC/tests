#include<stdio.h>
#include<graphics.h>
#include<math.h>

int max(int a, int b) {
    return (a > b) ? a : b;
}

void DDA(int x1,int y1,int x2,int y2){
	int dx=x2-x1;
	int dy=y2-y1;
	int step= max(dx,dy);
	float xinc=dx/(float)step;
	float yinc=dy/(float)step;
	float x=x1;
	float y=y1;
	for(int i=0;i<=step;i++){
		putpixel(round(x),round(y),WHITE);
		x+=xinc;
		y+=yinc;
	}
	
}

int main()
{
    int gd = DETECT, gm;
    int x0, y0, x1, y1;

    printf("Enter x0 y0: ");
    scanf("%d %d", &x0, &y0);

    printf("Enter x1 y1: ");
    scanf("%d %d", &x1, &y1);

    initgraph(&gd, &gm, NULL);
    DDA(x0,y0,x1,y1);
    getch();
    closegraph();

    return 0;
}
