#include <stdio.h>
#include <graphics.h>
#include <math.h>
#include <conio.h>

#define PI 3.14159265

// Structure to represent a point in Homogeneous Coordinates (x, y, w)
typedef struct {
    double x;
    double y;
    double w; // Always 1 for 2D points
} Point;


Point poly[10]; 
int n;         


void drawPolygon(Point p[], int n) {
    int i;

    setcolor(WHITE);
    
    for (i = 0; i < n; i++) {

        line((int)p[i].x, (int)p[i].y, (int)p[(i + 1) % n].x, (int)p[(i + 1) % n].y);
    }
}


void matrixMultiply(double m[3][3]) {
    int i;
    double newX, newY, newW;
    
    for (i = 0; i < n; i++) {
   
        newX = (m[0][0] * poly[i].x) + (m[0][1] * poly[i].y) + (m[0][2] * poly[i].w);
        newY = (m[1][0] * poly[i].x) + (m[1][1] * poly[i].y) + (m[1][2] * poly[i].w);
        newW = (m[2][0] * poly[i].x) + (m[2][1] * poly[i].y) + (m[2][2] * poly[i].w);
        

        poly[i].x = newX;
        poly[i].y = newY;
        poly[i].w = newW;
    }
}

void translate() {
    double tx, ty;
    double matrix[3][3];
    
    printf("Enter Translation factors (tx ty): ");
    scanf("%lf %lf", &tx, &ty);
    
    // Initializing Translation Matrix
    // | 1  0  tx |
    // | 0  1  ty |
    // | 0  0  1  |
    
    matrix[0][0] = 1; matrix[0][1] = 0; matrix[0][2] = tx;
    matrix[1][0] = 0; matrix[1][1] = 1; matrix[1][2] = ty;
    matrix[2][0] = 0; matrix[2][1] = 0; matrix[2][2] = 1;
    
    matrixMultiply(matrix);
    printf("Translation applied.\n");
}

void rotate() {
    double angle, rad;
    double matrix[3][3];
    
    printf("Enter Rotation angle (degrees, anti-clockwise): ");
    scanf("%lf", &angle);
    
    // Convert to radians
    rad = angle * (PI / 180.0);
    
    // Initializing Rotation Matrix (about origin)
    // | cos  -sin  0 |
    // | sin   cos  0 |
    // | 0     0    1 |
    
    matrix[0][0] = cos(rad); matrix[0][1] = -sin(rad); matrix[0][2] = 0;
    matrix[1][0] = sin(rad); matrix[1][1] = cos(rad);  matrix[1][2] = 0;
    matrix[2][0] = 0;        matrix[2][1] = 0;         matrix[2][2] = 1;
    
    matrixMultiply(matrix);
    printf("Rotation applied.\n");
}

void scale() {
    double sx, sy;
    double matrix[3][3];
    
    printf("Enter Scaling factors (sx sy): ");
    scanf("%lf %lf", &sx, &sy);
    
    // Initializing Scaling Matrix
    // | sx  0   0 |
    // | 0   sy  0 |
    // | 0   0   1 |
    
    matrix[0][0] = sx; matrix[0][1] = 0;  matrix[0][2] = 0;
    matrix[1][0] = 0;  matrix[1][1] = sy; matrix[1][2] = 0;
    matrix[2][0] = 0;  matrix[2][1] = 0;  matrix[2][2] = 1;
    
    matrixMultiply(matrix);
    printf("Scaling applied.\n");
}

int main() {
    int gd = DETECT, gm;
    int i, choice;
    

    initgraph(&gd, &gm, NULL);
    
    printf("--- Homogeneous Transformations ---\n");
    printf("Enter number of vertices (3 for triangle, 4 for rectangle): ");
    scanf("%d", &n);
    
    printf("Enter coordinates (x y) for each vertex:\n");
    for(i = 0; i < n; i++) {
        printf("Vertex %d: ", i+1);
        scanf("%lf %lf", &poly[i].x, &poly[i].y);
        poly[i].w = 1; 
    }
    

    cleardevice();
    drawPolygon(poly, n);
    outtextxy(10, 10, "Original Shape");
    
    do {

        printf("\nMENU:\n");
        printf("1. Translation\n");
        printf("2. Rotation (about origin)\n");
        printf("3. Scaling\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        
        switch(choice) {
            case 1:
                translate();
                break;
            case 2:
                rotate();
                break;
            case 3:
                scale();
                break;
            case 4:
                closegraph();
                return 0;
            default:
                printf("Invalid choice!\n");
        }
        
        cleardevice();

        line(0, 0, 640, 0); 
        line(0, 0, 0, 480); 
        outtextxy(5, 5, "(0,0)");
        
        drawPolygon(poly, n);
        
    } while (choice != 4);
    
    closegraph();
    return 0;
}
