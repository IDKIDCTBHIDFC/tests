#include <stdio.h>
#include <graphics.h>
#include <math.h>
#include <conio.h> // Added missing header

void DDA(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps, i;
    float xinc, yinc, x, y;

    if (abs(dx) > abs(dy))
        steps = abs(dx);
    else
        steps = abs(dy);

    xinc = dx / (float)steps;
    yinc = dy / (float)steps;

    x = x1;
    y = y1;

    for (i = 0; i <= steps; i++) {
        putpixel(round(x), round(y), WHITE);
        x += xinc;
        y += yinc;
    }
}

int main() {
    int gd = DETECT, gm;
    int n, i;
    // Arrays to store vertices (Max 10 for safety)
    int x[10], y[10]; 

    printf("Enter number of vertices (3 for Triangle, 4 for Rectangle): ");
    scanf("%d", &n);

    if (n < 3) {
        printf("A polygon must have at least 3 vertices.");
        return 0;
    }

    // Input loop for generic polygon
    for(i = 0; i < n; i++) {
        printf("Enter coordinates for vertex %d (x y): ", i + 1);
        scanf("%d %d", &x[i], &y[i]);
    }

    // Initialize graphics
    // Note: If using Turbo C++, change NULL to "C:\\TurboC3\\BGI"
    initgraph(&gd, &gm, NULL); 

    // Draw edges connecting points: 1-2, 2-3, 3-4...
    for(i = 0; i < n - 1; i++) {
        DDA(x[i], y[i], x[i+1], y[i+1]);
    }
    
    // 
    // Closing the loop: Connect Last Point -> First Point
    DDA(x[n-1], y[n-1], x[0], y[0]);

    getch();
    closegraph();
    return 0;
}
