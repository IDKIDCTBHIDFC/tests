#include<stdio.h>
#include<graphics.h>

void midpoint_circle(int x0,int y0,int radius){
	int x=0;
	int y=radius;
	int p0=1-radius;
	while(x<=y){
        putpixel(x0 + x, y0 + y, WHITE);
        putpixel(x0 + y, y0 + x, WHITE);
        putpixel(x0 - x, y0 + y, WHITE);
        putpixel(x0 - y, y0 + x, WHITE);
        putpixel(x0 + x, y0 - y, WHITE);
        putpixel(x0 + y, y0 - x, WHITE);
        putpixel(x0 - x, y0 - y, WHITE);
        putpixel(x0 - y, y0 - x, WHITE);
		if(p0>=0){
			x++;
			y--;
			p0=p0+2*x+1-2*y;
		}
		else{
			x++;
			p0=p0+2*x+1;
		}
	}
}

int main()
{
    int gd = DETECT, gm;
    int x0, y0, radius;

    printf("Enter center coordinates x0 y0: ");
    scanf("%d %d", &x0, &y0);

    printf("Enter radius of circle: ");
    scanf("%d", &radius);

    initgraph(&gd, &gm, NULL);
    midpoint_circle(x0,y0,radius);
    getch();
    closegraph();

    return 0;
}
